#!/usr/bin/env bash
set -u
{
for spec in "42 14" "44 15" "46 16" "48 17"; do
  set -- $spec; P=$1; PL=$2
  echo "=== START period $P (prefix $PL) at $(date -u +%H:%M:%S) ==="
  bash run_indep.sh "$P" "$PL" 12 "p${P}_indep_shards"
  echo "=== DONE  period $P at $(date -u +%H:%M:%S) ==="
done
echo "ALLDONE"
} > chain_indep.log 2>&1
