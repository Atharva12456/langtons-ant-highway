#!/usr/bin/env bash
set -u
{
echo "=== START period 48 (96-shard queue, 11 procs; p46 straggler owns 1 core) at $(date -u +%H:%M:%S) ==="
bash run_indep_q.sh 48 17 96 11 p48_indep_shards
echo "=== DONE  period 48 at $(date -u +%H:%M:%S) ==="
for spec in "34 10" "36 11" "38 12" "40 13"; do
  set -- $spec; P=$1; PL=$2
  echo "=== START period $P at $(date -u +%H:%M:%S) ==="
  bash run_indep_q.sh "$P" "$PL" 48 12 "p${P}_indep_shards"
  echo "=== DONE  period $P at $(date -u +%H:%M:%S) ==="
done
while [ ! -f p46_indep_shards/shard_01.json ]; do sleep 15; done
echo "=== AGGREGATE ==="
python aggregate_indep.py
echo "ALLREADY"
} > run_all.log 2>&1
