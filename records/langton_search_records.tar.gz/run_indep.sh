#!/usr/bin/env bash
# Sharded run of the Theorem-7.1-independent reference engine.
# Usage: run_indep.sh PERIOD PREFIXLEN NSHARDS OUTDIR
set -u
P=$1; PL=$2; NS=$3; OUT=$4
mkdir -p "$OUT"
TOTAL=$((1 << (PL - 1)))
STEP=$((TOTAL / NS))
echo "period=$P prefix_length=$PL total_ranks=$TOTAL shards=$NS step=$STEP -> $OUT"
pids=()
for ((s = 0; s < NS; ++s)); do
  A=$((s * STEP))
  B=$((A + STEP))
  if [ $s -eq $((NS - 1)) ]; then B=$TOTAL; fi
  java -cp indep_classes PositiveGrowthSearchIndep \
    --period "$P" --prefix-length "$PL" \
    --rank-start "$A" --rank-stop "$B" \
    --deficit-depths 0 \
    --output "$OUT/shard_$(printf '%02d' $s).json" \
    > "$OUT/shard_$(printf '%02d' $s).log" 2>&1 &
  pids+=($!)
done
fail=0
for p in "${pids[@]}"; do wait "$p" || fail=1; done
echo "all shards done (fail=$fail)"
exit $fail
